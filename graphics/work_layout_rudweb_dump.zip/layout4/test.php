<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en"><head> <title>Holy Grail update + fixes - Matthew Levine A List Apart - liquid CSS template by Matheson Bayley</title>

<meta name="description" content="Matheson Bayley - official website" />
<meta name="keywords" content="Holy Grail, update, fixes, Matthew Levine, A List Apart, liquid, CSS, template, Matheson Bayley" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index,follow" />
<meta http-equiv="Author" content="Matheson Bayley" />
<link rel="stylesheet" type="text/css" href="holy-grail-template-demo-style.css" /> <style type="text/css"></style></head>


<body>
<div id="header">

<div id="headerprop"></div>
<a style="position: absolute; top: 0px; left: 0px; z-index: -1; line-height: 1px;" name="top"> </a><br/><!-- ff anchor destination for 'back to top' buttons (if you have any!). IE doesn't require this, but the button will do nothing in ff without it --> 

<p>
HEADER
</p>

</div>   <!-- Close header div -->



<div id="container"> <div id="centercolumn" class="column"> <!-- CENTER COLUMN -->  <div style="position: relative; top: 0px; left: 0px; z-index: 2;"> <!-- TEXT WRAPPER ff 'negative z-index fix' to make background images appear. See notes after code for explanation. -->   <div class="prop"></div> <!-- IE MIN-HEIGHT HACK PART 1 -->





<h1>A List Apart Holy Grail Update + Fixes Template Demo</h1>

<p>
Content goes here. (What lovely colours these columns have! - Ugh!   :-)   )
</p>

<p>
<a href="article_holy_grail.php">Back to explanation + source code for this template</a>
</p>

      <div class="clear"></div> <!-- IE MIN-HEIGHT HACK PART 2 -->  </div> <!-- END text-wrapper 'ff negative z-index fix' -->





  <!-- The next section deals with adding multiple background images. It can be ignored if you don't need them. See notes after code for explanation -->  <!-- conditional comments for IE "z-index reset of floats within relatively positioned divs" bug. See notes after code for explanation -->



  <!--[if IE]>   <img style="position: absolute; z-index: -1; left: 0px; top: 0px;" src="images/center-column-top-left.jpg" alt=""/>   <img style="position: absolute; z-index: -1; right: 0px; top: 0px;" src="images/center-column-top-right.jpg" alt="" title=""/>  <![endif]-->  <!--[if !IE]> <!-->    <img style="position: absolute; z-index: 0; left: 0px; top: 0px;" src="images/center-column-top-left.jpg" alt="" title=""/>   <img style="position: absolute; z-index: 0; right: 0px; top: 0px;" src="images/center-column-top-right.jpg" alt="" title=""/>  <!--<![endif]-->   <!-- END conditional comments for 'IE z-index bug' -->  <!-- End of 'multiple background images' section. -->





   </div> <!-- END CENTER COLUMN -->



 <div id="leftcolumn" class="column"> <!-- LEFT COLUMN -->   <div style="position: relative; top: 0px; left: 0px; z-index: 2;"> <!-- TEXT WRAPPER ff neg z-index fix to make background images appear. See notes after code for explanation. -->


    <!-- insert left column text here -->

<p>
Left column
</p>

   </div> <!-- END text-wrapper ff neg z-index fix -->  <img id="left-column-graphic" src="images/left-column-graphic.jpg" alt="" title=""/>  <!-- has z-index of 1 --> </div>        <!-- END LEFT COLUMN -->




 <div id="rightcolumn" class="column"> <!-- RIGHT COLUMN -->



  <!-- insert right column text here -->


<p>
Right column
</p>


    <!-- The following conditional comments are only necessary if you have a graphic in the right column. IE7 doesn't display any of the three columns at all without a container div for the right column graphic! See notes after code for more detail. -->  <!--[if !IE 7]> <!-->   <img style="position: absolute; z-index: 0; right: 0px; top: 0px;" src="images/right-column-graphic.jpg" alt="" title=""/>  <!--<![endif]-->    <!--[if IE 7]>  <div>  <img style="position: absolute; z-index: 0; right: 0px; top: 0px;" src="images/right-column-graphic.jpg" alt="" title=""/>  </div>  <![endif]-->





  <!-- template continues from here if you didn't have an image in right column --> </div>         <!-- END RIGHT COLUMN --></div> <!-- closes container div -->





<div id="footer-wrapper"> <!-- IE6 fix for stopping the column backgrounds from spilling out over the footer if the page is not as tall as the viewport  -->  <div id="footer">   <div style="position: relative; z-index: 2; top: 0px; left: 0px;"> <!-- 'ff z-index fix' div -->        


<!-- insert footer text here -->   


<p>
Footer text<br/>
Footer text<br/>
Footer text<br/>

Footer text<br/>
Footer text<br/>
Footer text<br/>
Footer text
</p>    

</div>  <!-- close ff z-index fix div -->    <img style="position: absolute; z-index: 0; right: 0px; top: 0px;" src="images/footer-graphic.jpg" alt=""/>  </div>  <!-- close footer div  --></div> <!-- close IE6 footer wrapper div  --></body></html>