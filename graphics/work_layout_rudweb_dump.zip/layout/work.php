<?xml version="1.0" encoding="utf-8" standalone="no"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ro" lang="ro">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta http-equiv="content-language" content="ro" />
  <link rel="icon" type="image/ico" href="favicon.ico" />
  <link rel="shortcut icon" type="image/ico" href="favicon.ico" />
  <title>layout</title>
  <meta name="title" content="Administrare Con&#355;inut - Adaug&#259; Pagin&#259;" />
  <meta name="subject" content="Test Application" />
  <meta name="description" content="Test Application" />
  <meta name="keywords" content="Test Application, Administrare Con&#355;inut" />
  <meta name="copyright" content="Radu Maier" />
  <meta name="designer" content="Radu Maier" />
  <meta name="publisher" content="Radu Maier" />
  <meta name="author" content="Radu Maier" />
  <meta name="rating" content="General" />
  <meta name="distribution" content="Global" />
  <meta name="robots" content="Index, Follow" />
  <meta http-equiv="Content-Style-Type" content="text/css" />
  <link rel="stylesheet" type="text/css" charset="utf-8" href="style.css" />
</head>
<body>
  <div id="hdr">
    <div id="hdr1">
      <a href="{$smarty.const._APP_WWW}"><img id="logo" src="{$app_skin_url}graphics/logo.png" alt="{$smarty.const._APP_NAME} Logo" longdesc="{$smarty.const._APP_NAME} Logo" /></a>
    </div>
    <div id="hdr2"><div id="header">{$smarty.const._APP_NAME}</div></div>
    <div id="hdr3">&#160;</div>
  </div>

  <div id="cnt0">
      <div id="left0">
        &#160;
      </div>
      <div id="right0">
        &#160;
      </div>
      <div id="center0">
        &#160;
      </div>
  </div>
  

<div id="colmask">
	<div id="colmid">
		<div id="colright">
			<div id="col1wrap">
				<div id="col1pad">
					<div id="col1">
						<!-- Column 1 start -->
            column1
            <br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text<br />
            text x<br />
						<!-- Column 1 end -->
					</div>
				</div>
			</div>
			<div id="col2">
				<!-- Column 2 start -->
        column2
				<!-- Column 2 end -->
			</div>
			<div id="col3">
				<!-- Column 3 start -->
        column3
        
				<!-- Column 3 end -->

			</div>
		</div>
	</div>
</div>

  <div id="cnt2">
      <div id="left2">
        &#160;
      </div>
      <div id="right2">
        &#160;
      </div>
      <div id="center2">
        &#160;
      </div>
  </div>

  

  <div id="ftr">
    <div id="footer">
      {$footer}
    </div>
  </div>

<!-- http://matthewjamestaylor.com/blog/holy-grail-no-quirks-mode.htm -->

</body>
</html>
